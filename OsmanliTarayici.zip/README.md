# Osmanlı Tarayıcı

Android Studio'da aç, Build > Build APK(s).
