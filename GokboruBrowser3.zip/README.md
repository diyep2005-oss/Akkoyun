# Gökbörü Browser

Android Studio'da açıp ▶ Run'a bas (Android 10+ / API 29+). APK için: Build > Build APK(s).
Terminalden: gradle assembleDebug
